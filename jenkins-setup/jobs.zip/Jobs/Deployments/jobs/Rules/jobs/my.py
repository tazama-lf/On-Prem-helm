import os

# === CONFIGURATION ===
# Change this path to the parent directory containing your rule folders
BASE_DIR = "."

# --- Old text block (exactly as provided) ---
OLD_BLOCK = """sed -i &quot;s|ENV PSEUDONYMS_DATABASE_URL=|ENV PSEUDONYMS_DATABASE_URL=${ArangoPseudonymsURL}|g&quot; Dockerfile
sed -i &quot;s|ENV PSEUDONYMS_DATABASE_PASSWORD=|ENV PSEUDONYMS_DATABASE_PASSWORD=${ArangoPseudonymsPassword}|g&quot; Dockerfile
sed -i &quot;s|ENV TRANSACTION_HISTORY_DATABASE_URL=|ENV TRANSACTION_HISTORY_DATABASE_URL=${ArangoTransactionHistoryURL}|g&quot; Dockerfile
sed -i &quot;s|ENV TRANSACTION_HISTORY_DATABASE_PASSWORD=|ENV TRANSACTION_HISTORY_DATABASE_PASSWORD=${ArangoTransactionHistoryPassword}|g&quot; Dockerfile
sed -i &quot;s|ENV CONFIG_DATABASE_URL=|ENV CONFIG_DATABASE_URL=${ArangoConfigurationURL}|g&quot; Dockerfile
sed -i &quot;s|ENV CONFIG_DATABASE_PASSWORD=|ENV CONFIG_DATABASE_PASSWORD=${ArangoConfigurationPassword}|g&quot; Dockerfile"""

# --- New text block (exactly as provided) ---
NEW_BLOCK = """sed -i &quot;s|ENV RAW_HISTORY_DATABASE_HOST=|ENV RAW_HISTORY_DATABASE_HOST=${rawHisDbHost}|g&quot; Dockerfile
sed -i &quot;s|ENV RAW_HISTORY_DATABASE_PORT=|ENV RAW_HISTORY_DATABASE_PORT=${rawHisDbPort}|g&quot; Dockerfile
sed -i &quot;s|ENV RAW_HISTORY_DATABASE_USER=|ENV RAW_HISTORY_DATABASE_USER=${rawHisDbUser}|g&quot; Dockerfile
sed -i &quot;s|ENV RAW_HISTORY_DATABASE_PASSWORD=|ENV RAW_HISTORY_DATABASE_PASSWORD=${rawHisDbPassword}|g&quot; Dockerfile
sed -i &quot;s|ENV EVENT_HISTORY_DATABASE_HOST=|ENV EVENT_HISTORY_DATABASE_HOST=${eventHisDbHost}|g&quot; Dockerfile
sed -i &quot;s|ENV EVENT_HISTORY_DATABASE_PORT=|ENV EVENT_HISTORY_DATABASE_PORT=${eventHisDbPort}|g&quot; Dockerfile
sed -i &quot;s|ENV EVENT_HISTORY_DATABASE_USER=|ENV EVENT_HISTORY_DATABASE_USER=${eventHisDbUser}|g&quot; Dockerfile
sed -i &quot;s|ENV EVENT_HISTORY_DATABASE_PASSWORD=|ENV EVENT_HISTORY_DATABASE_PASSWORD=${eventHisDbPassword}|g&quot; Dockerfile
sed -i &quot;s|ENV CONFIGURATION_DATABASE_HOST=|ENV CONFIGURATION_DATABASE_HOST=${configDbHost}|g&quot; Dockerfile
sed -i &quot;s|ENV CONFIGURATION_DATABASE_PORT=|ENV CONFIGURATION_DATABASE_PORT=${configDbPort}|g&quot; Dockerfile
sed -i &quot;s|ENV CONFIGURATION_DATABASE_USER=|ENV CONFIGURATION_DATABASE_USER=${configDbUser}|g&quot; Dockerfile
sed -i &quot;s|ENV CONFIGURATION_DATABASE_PASSWORD=|ENV CONFIGURATION_DATABASE_PASSWORD=${configDbPassword}|g&quot; Dockerfile"""


def replace_in_file(file_path, old_text, new_text):
    """Replaces the exact old block with the new block in a file."""
    try:
        with open(file_path, "r", encoding="utf-8") as f:
            content = f.read()

        if old_text in content:
            updated = content.replace(old_text, new_text)
            with open(file_path, "w", encoding="utf-8") as f:
                f.write(updated)
            print(f"✅ Updated: {file_path}")
        else:
            print(f"⚠️ No match found in: {file_path}")
    except FileNotFoundError:
        print(f"❌ config.xml not found in: {os.path.dirname(file_path)}")
    except Exception as e:
        print(f"❌ Error processing {file_path}: {e}")


def process_rule_folders(base_dir):
    """Iterate through all rule-* folders and update config.xml files."""
    for folder in os.listdir(base_dir):
        folder_path = os.path.join(base_dir, folder)
        if os.path.isdir(folder_path) and folder.startswith("rule-"):
            config_path = os.path.join(folder_path, "config.xml")
            replace_in_file(config_path, OLD_BLOCK, NEW_BLOCK)


if __name__ == "__main__":
    process_rule_folders(BASE_DIR)
